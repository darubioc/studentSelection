package com.studentselection.candidates.controllers;

import com.studentselection.candidates.dto.DocumentTypeDTO;
import com.studentselection.candidates.services.DocumentTypeService;
import com.studentselection.candidates.services.QuestionnaireService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "Questionnaire")
public class AnswerController {

    @Autowired
    private QuestionnaireService questionnaireService;

    @GetMapping("/answers")
    public ResponseEntity<?> getAnswers(){
        try {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(questionnaireService.getDefaultAnswers());
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Por favor intente luego.\"}");
        }
    }

    @GetMapping("/questions")
    public ResponseEntity<?> getQuestions(){
        try {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(questionnaireService.getQuestions());
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Por favor intente luego.\"}");
        }
    }

    @GetMapping("/categories")
    public ResponseEntity<?> getAll(){
        try {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(questionnaireService.getCategories());
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Por favor intente luego.\"}");
        }
    }
}
