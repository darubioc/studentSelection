package com.studentselection.candidates.controllers;

import com.studentselection.candidates.dto.CandidateDTO;
import com.studentselection.candidates.services.CandidateCRUDService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.management.InstanceAlreadyExistsException;
import java.util.HashMap;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "candidates")
public class CandidateCRUDController {

    @Autowired
    private CandidateCRUDService candidateCRUDService;

    @GetMapping
    public ResponseEntity<Page<CandidateDTO>> getAll(@PageableDefault(size = 5) Pageable pageable){
//        try {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(candidateCRUDService.findAll(pageable));
//        }catch (Exception e){
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Por favor intente luego.\""+e+"}");
//        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getOne(@PathVariable Integer id){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(candidateCRUDService.findById(id));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Por favor intente luego.\""+e+"}");
        }
    }

    @PostMapping("/save")
    public ResponseEntity<?> save(@RequestBody CandidateDTO candidate){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(candidateCRUDService.save(candidate));
        }catch (Exception e){
            HashMap<String,String> responseJson = new HashMap<>();
            responseJson.put("Error","Error interno, el candidato no pudo crearse. "+e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseJson);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> save(@PathVariable Integer id,@RequestBody CandidateDTO candidate){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(candidateCRUDService.update(id,candidate));
        }catch (InstanceAlreadyExistsException e){
            return ResponseEntity.status(HttpStatus.OK).body(e.getMessage());
        }
        catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Por favor intente luego.\""+e+"}");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Integer id){
        try {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(candidateCRUDService.delete(id)==true?"Candidate deleted":"Candidate not found");
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Valide su solicitud. \""+e+"}");
        }
    }

    @PostMapping("/upload-file")
    public ResponseEntity<Boolean> uploadFile(@RequestParam("file") MultipartFile file) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(candidateCRUDService.uploadCandidates(file));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(false);
        }
    }


    @GetMapping("ageCalculator")
    public ResponseEntity<?> ageCalculate(){
        try{
            candidateCRUDService.updateCandidatesAge();
            return ResponseEntity.status(HttpStatus.OK).body("bien");
        }catch(Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. La consulta no arroja resultados.\""+e+"}");
        }
    }


}
