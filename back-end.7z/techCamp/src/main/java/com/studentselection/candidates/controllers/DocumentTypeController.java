package com.studentselection.candidates.controllers;

import com.studentselection.candidates.dto.DocumentTypeDTO;
import com.studentselection.candidates.services.DocumentTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "documentType")
public class DocumentTypeController {

    @Autowired
    private DocumentTypeService documentTypeService;

    @GetMapping("")
    public ResponseEntity<?> getAll(){
        try {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(documentTypeService.findAll());
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Por favor intente luego.\"}");
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getOne(@PathVariable Integer id){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(documentTypeService.findById(id));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Por favor intente luego.\"}");
        }
    }

    @PostMapping("/save")
    public ResponseEntity<?> save(@RequestBody DocumentTypeDTO doctypeDTO){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(documentTypeService.save(doctypeDTO));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Por favor intente luego.\""+e+"}");
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> save(@PathVariable Integer id,@RequestBody DocumentTypeDTO entity){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(documentTypeService.update(id,entity));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Por favor intente luego.\"}");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Integer id){
        try {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(documentTypeService.delete(id));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Por favor intente luego.\""+e+"}");
        }
    }
}
