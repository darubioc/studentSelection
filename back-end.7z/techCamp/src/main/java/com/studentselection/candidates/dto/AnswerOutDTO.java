package com.studentselection.candidates.dto;

import lombok.*;

import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class AnswerOutDTO implements Serializable {

    private Integer id;
    private Integer questionId;
    private String name;
    private String description;

}
