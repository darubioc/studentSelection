package com.studentselection.candidates.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.studentselection.candidates.entities.UserInformationEntity;
import lombok.*;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CandidateDTO {

    private Integer id;
    private String names;
    private String surnames;
    private Date birthday;
    private String docNum;
    private DocumentTypeDTO docType;
    private String email;
    private List<UserInformationDTO> userInformationList;

}
