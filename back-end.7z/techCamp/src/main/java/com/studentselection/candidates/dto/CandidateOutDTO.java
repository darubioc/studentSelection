package com.studentselection.candidates.dto;

import lombok.*;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CandidateOutDTO {

    private Integer id;
    private String names;
    private String surnames;
    private Date birthday;
    private String docNum;
    private DocumentTypeDTO docType;
    private String email;
    private List<UserInformationDTO> userInformationList;

}
