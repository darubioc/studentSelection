package com.studentselection.candidates.dto;

import lombok.*;
import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class CategoryDTO implements Serializable {

    private Integer id;
    private String name;

}
