package com.studentselection.candidates.dto;

import lombok.*;

import java.io.Serializable;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class CategoryOutDTO implements Serializable {

    private Integer id;
    private String name;
    private List<QuestionsOutDTO> questions;

}
