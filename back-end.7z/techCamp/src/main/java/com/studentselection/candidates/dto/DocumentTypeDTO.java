package com.studentselection.candidates.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DocumentTypeDTO {

    private Integer id;
    private String name;

}
