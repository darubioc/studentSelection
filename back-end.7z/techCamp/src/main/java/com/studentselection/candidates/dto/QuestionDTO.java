package com.studentselection.candidates.dto;

import lombok.*;
import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class QuestionDTO implements Serializable {

    private Integer id;
    private String name;
    private String description;
    private CategoryDTO category;

}
