package com.studentselection.candidates.dto;

import lombok.*;

import java.io.Serializable;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class QuestionsOutDTO implements Serializable {

    private Integer id;
    private Integer categoryId;
    private String name;
    private String description;

}
