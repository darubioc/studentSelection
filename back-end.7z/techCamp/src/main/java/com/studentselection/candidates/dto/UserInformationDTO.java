package com.studentselection.candidates.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class UserInformationDTO implements Serializable {

    private Integer id;
    private AnswerDTO answer;
    @JsonIgnore
    private CandidateDTO candidate;

}
