package com.studentselection.candidates.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="ANSWER")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class AnswerEntity implements Serializable {

    @Id
    @Column(name="ID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @Column(name="NAME")
    private String name;

    @Column(name="DESCRIPTION")
    private String description;

    @ManyToOne
    @JoinColumn(name="QUESTION", insertable = false, updatable = false)
    @JsonIgnore
    private QuestionEntity question;

    @Column(name="CREATIONDATE")
    private Date createdAt;

    @Column(name="UPDATEDATE")
    private Date updatedAt;

    @Column(name="DELETEDATE")
    private Date deletedAt;

    @Column(name="ACTIVE")
    private Boolean active;
}
