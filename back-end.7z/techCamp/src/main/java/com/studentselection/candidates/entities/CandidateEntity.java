package com.studentselection.candidates.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity
@Table(name="CANDIDATE")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class CandidateEntity implements Serializable {

    @Id
    @Column(name="ID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @Column(name="NAME")
    private String names;

    @Column(name="SURNAME")
    private String surnames;

    @Column(name="BIRTHDAY")
    private Date birthday;

    @Column(name="DOCUMENTNUMBER")
    private String docNum;

    //@Column(name="DOCUMENTTYPE")
    //private Integer docTypeId;
    @ManyToOne
    @JoinColumn(name="DOCUMENTTYPE")
    private DocumentTypeEntity docType;

    @Column(name="EMAIL")
    private String email;

    @OneToMany(mappedBy = "candidate", fetch = FetchType.EAGER)
    private List<UserInformationEntity> userInformationList;

    @Column(name="CREATIONDATE")
    private Date createdAt;

    @Column(name="UPDATEDATE")
    private Date updatedAt;

    @Column(name="DELETEDATE")
    private Date deletedAt;

    @Column(name="ACTIVE")
    private Boolean active;

}
