package com.studentselection.candidates.entities;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity
@Table(name="CATEGORY")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class CategoryEntity implements Serializable {

    @Id
    @Column(name="ID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @Column(name="NAME")
    private String name;

    @OneToMany(mappedBy = "category", fetch = FetchType.EAGER)
    private List<QuestionEntity> questions;

    @Column(name="CREATIONDATE")
    private Date createdAt;

    @Column(name="UPDATEDATE")
    private Date updatedAt;

    @Column(name="DELETEDATE")
    private Date deletedAt;

    @Column(name="ACTIVE")
    private Boolean active;
}
