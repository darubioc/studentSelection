package com.studentselection.candidates.entities;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="DOCUMENT_TYPE")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class DocumentTypeEntity implements Serializable {

    @Id
    @Column(name="ID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @Column(name="NAME")
    private String name;

    @Column(name="CREATIONDATE")
    private Date createdAt;

    @Column(name="UPDATEDATE")
    private Date updatedAt;

    @Column(name="DELETEDATE")
    private Date deletedAt;

    @Column(name="ACTIVE")
    private Boolean active;
}
