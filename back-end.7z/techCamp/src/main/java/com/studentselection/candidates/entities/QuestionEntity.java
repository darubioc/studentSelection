package com.studentselection.candidates.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity
@Table(name="QUESTION")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class QuestionEntity implements Serializable {

    @Id
    @Column(name="ID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @Column(name="NAME")
    private String name;

    @Column(name="DESCRIPTION")
    private String description;

    @ManyToOne
    @JoinColumn(name="CATEGORY", insertable = false, updatable = false)
    @JsonIgnore
    private CategoryEntity category;

    @OneToMany(mappedBy = "question", fetch = FetchType.EAGER)
    private List<AnswerEntity> answers;

    @Column(name="CREATIONDATE")
    private Date createdAt;

    @Column(name="UPDATEDATE")
    private Date updatedAt;

    @Column(name="DELETEDATE")
    private Date deletedAt;

    @Column(name="ACTIVE")
    private Boolean active;
}
