package com.studentselection.candidates.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="USER_INFORMATION")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class UserInformationEntity implements Serializable {

    @Id
    @Column(name="ID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name="ANSWER")
    private AnswerEntity answer;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="CANDIDATE")
    @JsonIgnore
    private CandidateEntity candidate;

    @Column(name="CREATIONDATE")
    private Date createdAt;

    @Column(name="UPDATEDATE")
    private Date updatedAt;

    @Column(name="DELETEDATE")
    private Date deletedAt;

    @Column(name="ACTIVE")
    private Boolean active;
}
