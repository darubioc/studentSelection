package com.studentselection.candidates.mapper;

import com.studentselection.candidates.dto.AnswerDTO;
import com.studentselection.candidates.dto.QuestionDTO;
import com.studentselection.candidates.entities.AnswerEntity;
import com.studentselection.candidates.entities.QuestionEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AnswerMapper extends Mapper<AnswerEntity, AnswerDTO> {

    @Autowired
    QuestionMapper questionMapper;

    public AnswerDTO toDomain(AnswerEntity answer) {
        return (answer != null) ? AnswerDTO.builder()
                .id(answer.getId())
                .name(answer.getName())
                .description(answer.getDescription())
                .question(questionMapper.toDomain(answer.getQuestion()))
                .build() : null;
    }
    public AnswerEntity toEntity(AnswerDTO answer) {
        return (answer != null) ? AnswerEntity.builder()
                .id(answer.getId())
                .name(answer.getName())
                .description(answer.getDescription())
                .question(questionMapper.toEntity(answer.getQuestion()))
                .build() : null;
    }
}
