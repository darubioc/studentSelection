package com.studentselection.candidates.mapper;

import com.studentselection.candidates.dto.AnswerDTO;
import com.studentselection.candidates.dto.AnswerOutDTO;
import com.studentselection.candidates.entities.AnswerEntity;
import com.studentselection.candidates.entities.QuestionEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AnswerOutMapper extends Mapper<AnswerEntity, AnswerOutDTO> {

    public AnswerOutDTO toDomain(AnswerEntity answer) {
        return (answer != null) ? AnswerOutDTO.builder()
                .id(answer.getId())
                .name(answer.getName())
                .description(answer.getDescription())
                .questionId(answer.getQuestion().getId())
                .build() : null;
    }
    public AnswerEntity toEntity(AnswerOutDTO answer) {
        return (answer != null) ? AnswerEntity.builder()
                .id(answer.getId())
                .name(answer.getName())
                .description(answer.getDescription())
                .question(QuestionEntity.builder().id(answer.getQuestionId()).build())
                .build() : null;
    }
}
