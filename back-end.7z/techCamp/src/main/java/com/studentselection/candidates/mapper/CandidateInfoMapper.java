package com.studentselection.candidates.mapper;

import com.studentselection.candidates.dto.CandidateDTO;
import com.studentselection.candidates.entities.CandidateEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CandidateInfoMapper extends Mapper<CandidateEntity, CandidateDTO> {

    @Autowired
    DocumentTypeMapper documentTypeMapper;
    @Autowired
    UserInformationMapper userInformationMapper;
    public CandidateDTO toDomain(CandidateEntity candidate) {
        return CandidateDTO.builder()
                .id(candidate.getId())
                .names(candidate.getNames())
                .surnames(candidate.getSurnames())
                .birthday(candidate.getBirthday())
                .docNum(candidate.getDocNum())
                .docType(documentTypeMapper.toDomain(candidate.getDocType()))
                .email(candidate.getEmail())
                .userInformationList(userInformationMapper.toDomainList(candidate.getUserInformationList()))
                .build();
    }
    public CandidateEntity toEntity(CandidateDTO candidate) {
         CandidateEntity candidateEntity = CandidateEntity.builder()
                .id(candidate.getId())
                .names(candidate.getNames())
                .surnames(candidate.getSurnames())
                .birthday(candidate.getBirthday())
                .docNum(candidate.getDocNum())
                .docType(documentTypeMapper.toEntity(candidate.getDocType()))
                 .userInformationList(candidate.getUserInformationList()==null?null:userInformationMapper.toEntityList(candidate.getUserInformationList()))
                 .email(candidate.getEmail())
                 .build();
         return candidateEntity;
    }

}
