package com.studentselection.candidates.mapper;

import com.studentselection.candidates.dto.CandidateDTO;
import com.studentselection.candidates.dto.CategoryDTO;
import com.studentselection.candidates.entities.CandidateEntity;
import com.studentselection.candidates.entities.CategoryEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class CategoryMapper extends Mapper<CategoryEntity, CategoryDTO> {

    public CategoryDTO toDomain(CategoryEntity category) {
        return (category != null) ? CategoryDTO.builder()
                .id(category.getId())
                .name(category.getName())
                .build() : null;
    }
    public CategoryEntity toEntity(CategoryDTO category) {
        return (category != null) ?  CategoryEntity.builder()
                .id(category.getId())
                .name(category.getName())
                .build() : null;
    }
}
