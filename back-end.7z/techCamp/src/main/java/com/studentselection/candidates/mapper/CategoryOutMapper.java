package com.studentselection.candidates.mapper;

import com.studentselection.candidates.dto.CategoryDTO;
import com.studentselection.candidates.dto.CategoryOutDTO;
import com.studentselection.candidates.entities.CategoryEntity;
import org.springframework.stereotype.Component;

@Component
public class CategoryOutMapper extends Mapper<CategoryEntity, CategoryOutDTO> {

    public CategoryOutDTO toDomain(CategoryEntity category) {
        return (category != null) ? CategoryOutDTO.builder()
                .id(category.getId())
                .name(category.getName())
                .build() : null;
    }
    public CategoryEntity toEntity(CategoryOutDTO category) {
        return (category != null) ?  CategoryEntity.builder()
                .id(category.getId())
                .name(category.getName())
                .build() : null;
    }
}
