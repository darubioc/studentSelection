package com.studentselection.candidates.mapper;

import com.studentselection.candidates.dto.DocumentTypeDTO;
import com.studentselection.candidates.entities.DocumentTypeEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class DocumentTypeMapper extends Mapper<DocumentTypeEntity,DocumentTypeDTO> {

    public DocumentTypeDTO toDomain(DocumentTypeEntity docType) {
        return (docType != null) ? DocumentTypeDTO.builder()
                .id(docType.getId())
                .name(docType.getName())
                .build() : null;
    }
    public DocumentTypeEntity toEntity(DocumentTypeDTO docType) {
        return DocumentTypeEntity.builder()
                .id(docType.getId())
                .name(docType.getName())
                .build();
    }
}
