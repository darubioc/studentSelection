package com.studentselection.candidates.mapper;

import org.springframework.data.domain.Page;

import java.util.List;
import java.util.stream.Collectors;

public abstract class Mapper<ENTITY, DTO> {

    public abstract DTO toDomain(ENTITY entity);

    public abstract ENTITY toEntity(DTO dto);

    public List<DTO> toDomainList(List<ENTITY> listEntity){
        return listEntity.stream()
                .map(entity -> toDomain(entity))
                .collect(Collectors.toList());
    }
    public Page<DTO> toDomainPage(Page<ENTITY> entityPage){
        return entityPage.map(this::toDomain);
    }

    public List<ENTITY> toEntityList(List<DTO> listDto){
        return listDto.stream()
                .map(dto -> toEntity(dto))
                .collect(Collectors.toList());
    }
}
