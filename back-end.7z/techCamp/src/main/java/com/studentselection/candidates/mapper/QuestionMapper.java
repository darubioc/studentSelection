package com.studentselection.candidates.mapper;

import com.studentselection.candidates.dto.CategoryDTO;
import com.studentselection.candidates.dto.QuestionDTO;
import com.studentselection.candidates.entities.CategoryEntity;
import com.studentselection.candidates.entities.QuestionEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class QuestionMapper extends Mapper<QuestionEntity, QuestionDTO> {

    @Autowired
    CategoryMapper categoryMapper;

    public QuestionDTO toDomain(QuestionEntity question) {
        return (question != null) ? QuestionDTO.builder()
                .id(question.getId())
                .name(question.getName())
                .description(question.getDescription())
                .category(categoryMapper.toDomain(question.getCategory()))
                .build() : null;
    }
    public QuestionEntity toEntity(QuestionDTO question) {
        return (question != null) ? QuestionEntity.builder()
                .id(question.getId())
                .name(question.getName())
                .description(question.getDescription())
                .category(categoryMapper.toEntity(question.getCategory()))
                .build() : null;
    }
}
