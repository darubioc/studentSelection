package com.studentselection.candidates.mapper;

import com.studentselection.candidates.dto.QuestionDTO;
import com.studentselection.candidates.dto.QuestionsOutDTO;
import com.studentselection.candidates.entities.CategoryEntity;
import com.studentselection.candidates.entities.QuestionEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class QuestionOutMapper extends Mapper<QuestionEntity, QuestionsOutDTO> {

    public QuestionsOutDTO toDomain(QuestionEntity question) {
        return (question != null) ? QuestionsOutDTO.builder()
                .id(question.getId())
                .name(question.getName())
                .description(question.getDescription())
                .categoryId(question.getCategory().getId())
                .build() : null;
    }
    public QuestionEntity toEntity(QuestionsOutDTO question) {
        return (question != null) ? QuestionEntity.builder()
                .id(question.getId())
                .name(question.getName())
                .description(question.getDescription())
                .category(CategoryEntity.builder().id(question.getId()).build())
                .build() : null;
    }
}
