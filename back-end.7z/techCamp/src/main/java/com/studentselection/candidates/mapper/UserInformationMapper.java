package com.studentselection.candidates.mapper;

import com.studentselection.candidates.dto.AnswerDTO;
import com.studentselection.candidates.dto.CandidateDTO;
import com.studentselection.candidates.dto.UserInformationDTO;
import com.studentselection.candidates.entities.AnswerEntity;
import com.studentselection.candidates.entities.CandidateEntity;
import com.studentselection.candidates.entities.UserInformationEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserInformationMapper extends Mapper<UserInformationEntity, UserInformationDTO> {

    @Autowired
    AnswerMapper answerMapper;

    public UserInformationDTO toDomain(UserInformationEntity userInfo) {
        return (userInfo != null) ? UserInformationDTO.builder()
                .id(userInfo.getId())
                .answer(answerMapper.toDomain(userInfo.getAnswer()))
                .build() : null;
    }
    public UserInformationEntity toEntity(UserInformationDTO userInfo) {
        return (userInfo != null) ? UserInformationEntity.builder()
                .id(userInfo.getId())
                .answer(answerMapper.toEntity(userInfo.getAnswer()))
                .build() : null;
    }
    public UserInformationEntity toEntity(UserInformationDTO userInfo, CandidateEntity candidate, AnswerEntity answer) {
        return (userInfo != null) ? UserInformationEntity.builder()
                .id(userInfo.getId() != null ? userInfo.getId() : null)
                .answer(answer)
                .candidate(candidate)
                .build() : null;
    }
}
