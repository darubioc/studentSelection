package com.studentselection.candidates.repositories;

import com.studentselection.candidates.entities.CandidateEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CandidateFileRepository extends JpaRepository<CandidateEntity,Integer> {

}
