package com.studentselection.candidates.repositories;

import com.studentselection.candidates.entities.CandidateEntity;
import com.studentselection.candidates.entities.UserInformationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserInformationRepository extends JpaRepository<UserInformationEntity,Integer> {
    Optional<UserInformationEntity> findByIdAndActive(Integer id, Boolean active);

    List<UserInformationEntity> findByCandidate(CandidateEntity candidateId);

}
