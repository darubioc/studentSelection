package com.studentselection.candidates.services;

import com.studentselection.candidates.dto.CandidateDTO;
import com.studentselection.candidates.dto.UserInformationDTO;
import com.studentselection.candidates.entities.AnswerEntity;
import com.studentselection.candidates.entities.CandidateEntity;
import com.studentselection.candidates.entities.UserInformationEntity;
import com.studentselection.candidates.mapper.CandidateInfoMapper;
import com.studentselection.candidates.mapper.CandidateSaveMapper;
import com.studentselection.candidates.mapper.UserInformationMapper;
import com.studentselection.candidates.repositories.AnswerRepository;
import com.studentselection.candidates.repositories.CandidateCRUDRepository;
import com.studentselection.candidates.repositories.UserInformationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.management.InstanceAlreadyExistsException;
import javax.transaction.Transactional;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class CandidateCRUDService implements ICandidateService<CandidateDTO> {

    @Autowired
    private CandidateCRUDRepository candidateCRUDRepository;
    @Autowired
    private UserInformationRepository userInformationRepository;
    @Autowired
    private AnswerRepository answerRepository;

    @Autowired
    private CandidateInfoMapper candidateInfoMapper;
    @Autowired
    private CandidateSaveMapper candidateSaveMapper;
    @Autowired
    private QuestionnaireService questionnaireService;

    @Autowired
    private JdbcTemplate jdbcTemplate;
    private SimpleJdbcCall simpleJdbcCall;


    @Override
    @Transactional
    public Page<CandidateDTO> findAll(Pageable pageable){
//        try{
            return candidateInfoMapper.toDomainPage(candidateCRUDRepository.findByActive(true,pageable));
//        }catch (Exception e){
//            throw new Exception(e.getMessage());
//        }
    }

    @Transactional
    public List<CandidateDTO> findAllCandidates() throws Exception{
        try{
            return candidateInfoMapper.toDomainList(candidateCRUDRepository.findAll());
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }

    @Override
    @Transactional
    public CandidateDTO findById(Integer id) throws Exception {
        try{
            Optional<CandidateEntity> entityOptional = candidateCRUDRepository.findById(id);
            return candidateInfoMapper.toDomain(entityOptional.get());
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }


    /**
     * Este método se encarga de guardar un candidato, lanzamiento de excepciones
     * y manejo de posibles inserciones de candidatos con datos únicos que no deben repetirse
     * @author DiegoAndresRubioCasallas - CC1032493492
     * @param candidate compone todas las propiedades necesarias para crear un candidato
     * @return CandidateDTO creado dentro de la función
     */
    @Override
    @Transactional
    public CandidateDTO save(CandidateDTO candidate) throws Exception {
        try{
            Optional<CandidateEntity> opCandidateDeleted = candidateCRUDRepository.findByDocNum(candidate.getDocNum());
            CandidateEntity candidateEntity = candidateInfoMapper.toEntity(candidate);
            if(opCandidateDeleted.isEmpty()){
                candidateEntity.setCreatedAt(new Date());
                candidateEntity.setUpdatedAt(new Date());
                candidateEntity.setActive(true);
                CandidateEntity candidateSaved = candidateCRUDRepository.save(candidateEntity);
                if(!saveUserInformation(candidate.getUserInformationList(),candidateInfoMapper.toDomain(candidateSaved))){
                    throw new Exception("Candidate details couldn't be saved");
                }
                Optional<CandidateEntity> opCandEntity = candidateCRUDRepository.findById(candidateSaved.getId());
                setAgepublic(opCandEntity.get());
                return candidateInfoMapper.toDomain(opCandEntity.isPresent()?opCandEntity.get():null);
            }else{
                if(opCandidateDeleted.get().getActive()==false){
                    CandidateEntity cadEnt = candidateCRUDRepository.findById(opCandidateDeleted.get().getId()).get();
                    cadEnt.setActive(true);
                    this.update(opCandidateDeleted.get().getId(), candidateInfoMapper.toDomain(cadEnt));
                    throw new InstanceAlreadyExistsException("Document number already exist, candidate were updated.");
                }else{
                    throw new Exception("Candidate does already exist and it's status is:"+opCandidateDeleted.get().getActive());
                }
            }
        }catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    /**
     * Este método se encarga de guardar la información a un candidato asociado, estos registros
     * pueden crecer tanto como posibles respuestas se creen en tabla Answers del modelo de datos.
     * @author DiegoAndresRubioCasallas - CC1032493492
     * @param userInfoList contiene una lista de todas las respuestas que dan información detallada del candidato
     * @param candidate contiene información del candidato al que se le desea relacionar la información detallada
     * @return Boolean valor true para operación satisfactoria. Exception para operación no lograda.
     */
    @Transactional
    public Boolean saveUserInformation(List<UserInformationDTO> userInfoList,CandidateDTO candidate) throws  Exception{
        try{
            for (UserInformationDTO userInfo : userInfoList) {
                AnswerEntity answer = answerRepository.findById(userInfo.getAnswer().getId()).get();
                if(answer==null)
                    continue;
                UserInformationEntity userInfoEntity = new UserInformationEntity();
                userInfoEntity.setCandidate(candidateSaveMapper.toEntity(candidate));
                userInfoEntity.setAnswer(answer);
                userInfoEntity.setActive(true);
                userInfoEntity.setCreatedAt(new Date());
                userInfoEntity.setUpdatedAt(new Date());
                userInformationRepository.save(userInfoEntity);
            }
            return true;
        }catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    /**
     * Este método se encarga de actualizar la edad de un candidato que cumpla años en el día en que se ejecuta
     * la función:
     * -Se realiza una consulta con JPQL para obtener los candidatos que cumplan años.
     * -Se obtiene un listado de respuestas y posteriormente se filtran las respuestas que correspondan a la pregunta
     * de edad.
     * -Se obtiene la edad en años del candidato a actualizar.
     * -Se ejecuta el guardado/actualización de la respuesta edad en el usuario.
     * @params propiedad @Scheduled(cron) permite controlar la frecuencia en que se ejecuta este proceso.
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    @Scheduled(cron = "0 2 13 * * ?")
    public void updateCandidatesAge(){
        try{
            List<CandidateEntity> candidateList = candidateCRUDRepository.findByBirthday();
            List<AnswerEntity> answerList = answerRepository.findAll();
            List<AnswerEntity> ageAnswerList = answerList.stream().filter(answer -> answer.getQuestion().getName().toLowerCase().equals("age")).collect(Collectors.toList());

            candidateList.forEach(candidate -> {
                Integer age = calcCandidateAge(candidate);
                ageAnswerList.forEach((rangeAges)->{
                    String str = rangeAges.getName();
                    String[] arrOfStr = str.split("-", 2);
                    if(age <Integer.parseInt(arrOfStr[1])
                            && age >Integer.parseInt(arrOfStr[0])){
                        AnswerEntity tempAns=answerList.stream().filter(userInfo -> userInfo.getId()==rangeAges.getId())
                                .findAny()
                                .orElse(null);
                        try {
                            updateBirthAnswer(candidate,tempAns);
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    }
                });
            });

        }catch (Exception e){
            System.out.println("No se pudo actualizar la edad de los candidatos.");
        }
    }

    /**
     * Este método se encarga de asignar la edad a un candidato que recién se haya creado.
     * -Se obtiene un listado de respuestas y posteriormente se filtran las respuestas que correspondan a la pregunta
     * de edad.
     * -Se obtiene la edad en años del candidato a actualizar.
     * -Se ejecuta el guardado/actualización de la respuesta edad en el usuario.
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    public void setAgepublic(CandidateEntity candidate) throws Exception {
        try{
            List<AnswerEntity> answerList = answerRepository.findAll();
            List<AnswerEntity> ageAnswerList = answerList.stream().filter(answer -> answer.getQuestion().getName().toLowerCase().equals("age")).collect(Collectors.toList());

            Integer age = calcCandidateAge(candidate);
            ageAnswerList.forEach((rangeAges)->{
                String str = rangeAges.getName();
                String[] arrOfStr = str.split("-", 2);
                if(age <Integer.parseInt(arrOfStr[1])
                        && age >Integer.parseInt(arrOfStr[0])){
                    AnswerEntity tempAns=answerList.stream().filter(userInfo -> userInfo.getId()==rangeAges.getId())
                            .findAny()
                            .orElse(null);
                    try {
                        updateBirthAnswer(candidate,tempAns);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            });

        }catch (Exception e){
            throw new Exception("No se pudo actualizar la edad de los candidatos. "+e.getMessage());
        }
    }

    /**
     * Este método se encarga de asignar la edad a un candidato que recién se haya creado.
     * @param candidate corresponde al candidato al que se le requiere calcular la edad para su posterior guardado
     * @return Integer age/edad, corresponde a la edad del candidato pasado por parámetro.
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    public Integer calcCandidateAge(CandidateEntity candidate){
        LocalDate fechaNac = candidate.getBirthday().toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        LocalDate now = LocalDate.now();
        Period periodo = Period.between(fechaNac, now);
        return periodo.getYears();
    }
    /**
     * Método relaciona en base de datos la respuesta (rango de edades) conseguida y el candidato en cuestión, esto por
     * medio de una tabla de rompimiento llamada User_Information que relaciona un candidato con sus respuestas.
     * @param localCandidate corresponde al candidato al que se requiere guardar el rango de edad.
     * @param answer corresponde a la respuesta (rango de edad) obtenido previamente
     * @return boolean true para operación exitosa
     * @return exception para operación frustrada
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    @Transactional
    public boolean updateBirthAnswer(CandidateEntity localCandidate,AnswerEntity answer) throws Exception {
        try{
            List<UserInformationEntity> userInfoList = userInformationRepository.findByCandidate(localCandidate);
            UserInformationEntity candidateAnswerAges = userInfoList.stream()
                    .filter(userInfo -> userInfo.getAnswer().getQuestion().getName().toLowerCase().equals("age"))
                    .findAny()
                    .orElse(null);

            UserInformationEntity usinfo= UserInformationEntity.builder()
                    .id(candidateAnswerAges ==null?null:candidateAnswerAges.getId())
                    .candidate(localCandidate)
                    .createdAt(candidateAnswerAges ==null?new Date():candidateAnswerAges.getCreatedAt())
                    .updatedAt(new Date())
                    .answer(answer)
                    .active(candidateAnswerAges ==null ? true:candidateAnswerAges.getActive())
                    .build();
            userInformationRepository.save(usinfo);
            return true;
        }catch (Exception e){
            throw new Exception("Hubo un error al guardar la respuesta de tipo edad. "+e.getMessage());
        }
    }

    /**
     * Método encargado de actualizar un candidato específico.
     * @param id corresponde al identificador en base de datos del candidato a actualizar.
     * @param candidate corresponde al contenido que se pretende modificar en base de datos.
     * @return CandidateDTO corresponde al candidato actualizado
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    @Override
    @Transactional
    public CandidateDTO update(Integer id, CandidateDTO candidate) throws Exception {
        try{
            Optional<CandidateEntity> candidateOptional = candidateCRUDRepository.findById(id);
            if(candidateOptional.isPresent()) {
                CandidateEntity candidateEntity = candidateInfoMapper.toEntity(candidate);
                candidateEntity.setId(candidateOptional.get().getId());
                candidateEntity.setCreatedAt(candidateOptional.get().getCreatedAt());
                candidateEntity.setUpdatedAt(new Date());
                candidateEntity.setActive(true);
                CandidateEntity candidateSaved = candidateCRUDRepository.save(candidateEntity);
                if(!updateUserInformation(candidate.getUserInformationList(),candidateSaved.getId())){
                    throw new Exception("Candidate details couldn't be saved");
                }
                return candidateInfoMapper.toDomain(candidateSaved);
            }else{
                throw new Exception("Could not find candidate with id: "+candidateOptional.get().getId());
            }
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }

    /**
     * Método encargado de actualizar la información adicional de un candidato en específico.
     * @param userInfoList corresponde a la lista de información adicional a actualizar.
     * @param candidateId corresponde al candidato al que se requiere actualizar la información.
     * @return Boolean = true para operación exitosa
     * @throws Exception para operación fracasada
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    @Transactional
    public Boolean updateUserInformation(List<UserInformationDTO> userInfoList,Integer candidateId) throws  Exception{
        try{
            Optional<CandidateEntity> candidateEntity = candidateCRUDRepository.findById(candidateId);
            for (UserInformationDTO userInfo : userInfoList) {
                Optional<UserInformationEntity> userInformationOptional = userInformationRepository.findByIdAndActive(userInfo.getId(),true);
                if(candidateEntity.isPresent()) {
                    AnswerEntity answer = answerRepository.findById(userInfo.getAnswer().getId()).get();
                    UserInformationEntity userInfoEntity = userInformationOptional.isPresent()? userInformationOptional.get(): new UserInformationEntity();
                    userInfoEntity.setCandidate(candidateEntity.get());
                    userInfoEntity.setAnswer(answer);
                    userInfoEntity.setActive(true);
                    userInfoEntity.setUpdatedAt(new Date());
                    userInfoEntity.setCreatedAt(userInfoEntity.getCreatedAt()!=null?userInfoEntity.getCreatedAt():new Date());
                    userInformationRepository.save(userInfoEntity);
                }else{
                    return false;
                }
            }
            return true;
        }catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    /**
     * Método encargado de eliminar por soft delete (inactivar) un candidato específico.
     * @param id corresponde al identificador en base de datos del candidato a inactivar.
     * @return Boolean = true para operación exitosa
     * @throws Exception para operación fracasada
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    @Override
    @Transactional
    public boolean delete(Integer id) throws NoSuchElementException {
        try{
            CandidateEntity candidate = candidateCRUDRepository.findById(id).get();
            candidate.setDeletedAt(new Date());
            candidate.setActive(false);
            candidateCRUDRepository.save(candidate);
            List<UserInformationEntity> userInfoList = candidate.getUserInformationList();
            deleteUserInformation(userInfoList);
            return true;
        }catch (Exception e) {
            throw new NoSuchElementException();
        }
    }

    /**
     * Método encargado de eliminar el detalle de la información de un usuario.
     * @param userInfoList corresponde al grupo de datos a eliminar.
     * @return Boolean = true para operación exitosa
     * @throws Exception para operación fracasada
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    @Transactional
    public boolean deleteUserInformation(List<UserInformationEntity> userInfoList) throws NoSuchElementException {
        try{
//            for (UserInformationEntity userInfo: userInfoList) {
//                userInfo.setDeletedAt(new Date());
//                userInfo.setActive(false);
//                userInformationRepository.save(userInfo);
//            }
            for (UserInformationEntity userInfo: userInfoList) {
                userInformationRepository.deleteById(userInfo.getId());
            }
            return true;
        }catch (Exception e) {
            throw new NoSuchElementException();
        }
    }

    /**
     * Método encargado de cargar candidatos al sistema mediante un archivo.
     * - Carga el archivo en una ubicación específica requerida por la base de datos
     * @param file corresponde al archivo que contiene los candidatos a cargar.
     * @return Boolean = true para operación exitosa
     * @throws NoSuchElementException para operación fracasada
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    public boolean uploadCandidates(MultipartFile file) throws NoSuchElementException {
        try{
            String folder = "C:\\Users\\Public\\candidatos\\";
            if(!file.isEmpty()) {
                try {
                    byte [] bytes = file.getBytes();
                    Path path = Paths.get(folder+"CANDIDATOS.txt");
                    Files.write(path, bytes);

                    execImportDataProcedure();

                    return true;
                } catch (IOException e) {
                    e.printStackTrace();
                    return false;
                }
            }
            return true;
        }catch (Exception e) {
            throw new NoSuchElementException();
        }
    }

    /**
     * Método encargado de ejecutar el procedimiento almacenado en determinado paquete,
     * para que por medio de éste se lea el archivo y se guarden en base de datos.
     * Se especifica el paquete y el nombre del procedimiento almacenado.
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    @Scheduled(cron = "0 0 7 15 * ?")
    public void execImportDataProcedure() {
        simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withCatalogName("LOAD_CANDIDATES")
                .withProcedureName("CREATE_CANDIDATES_FROM_FILE");

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("FILE_NAME", "CANDIDATOS.txt");

        Map<String, Object> out = simpleJdbcCall.execute(in);
    }


}
