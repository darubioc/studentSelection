package com.studentselection.candidates.services;

import com.studentselection.candidates.dto.DocumentTypeDTO;
import com.studentselection.candidates.entities.DocumentTypeEntity;
import com.studentselection.candidates.mapper.DocumentTypeMapper;
import com.studentselection.candidates.repositories.DocumentTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class DocumentTypeService implements ICrudService<DocumentTypeDTO> {

    @Autowired
    private DocumentTypeRepository documentTypeRepository;

    @Autowired
    private DocumentTypeMapper documentTypeMapper;
    @Override
    @Transactional
    public List<DocumentTypeDTO> findAll() throws Exception {
        try{
            return documentTypeMapper.toDomainList(documentTypeRepository.findByActive(true));
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }

    @Override
    @Transactional
    public DocumentTypeDTO findById(Integer id) throws Exception {
        try{
            Optional<DocumentTypeEntity> entityOptional = documentTypeRepository.findById(id);
            return documentTypeMapper.toDomain(entityOptional.get());
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }

    @Override
    @Transactional
    public DocumentTypeDTO save(DocumentTypeDTO doctypeDTO) throws Exception {
        try{
            DocumentTypeEntity doctypeEntity = documentTypeRepository.save(documentTypeMapper.toEntity(doctypeDTO));
            return documentTypeMapper.toDomain(doctypeEntity);
        }catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Override
    @Transactional
    public DocumentTypeDTO update(Integer id, DocumentTypeDTO doctypeDTO) throws Exception {
        try{
            Optional<DocumentTypeEntity> docTypeOptional = documentTypeRepository.findById(id);
            if(docTypeOptional.isPresent()){
                DocumentTypeEntity docTypeEntity = documentTypeMapper.toEntity(doctypeDTO);
                docTypeEntity.setId(docTypeOptional.get().getId());
                docTypeEntity.setCreatedAt(docTypeOptional.get().getCreatedAt());
                docTypeEntity.setUpdatedAt(new Date());
                return documentTypeMapper.toDomain(documentTypeRepository.save(docTypeEntity));
            }else{
                throw new Exception("Could not find document type by id: "+docTypeOptional.get().getId());
            }
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }

    @Override
    @Transactional
    public boolean delete(Integer id) throws Exception {
        try{
            if(documentTypeRepository.existsById(id)){
                documentTypeRepository.deleteById(id);
                return true;
            } else{
                throw new Exception();
            }
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }
}
