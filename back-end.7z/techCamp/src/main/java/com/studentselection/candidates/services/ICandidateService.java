package com.studentselection.candidates.services;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ICandidateService<E> {
    public Page<E> findAll(Pageable pageNumber) throws Exception;
    public E findById(Integer id) throws Exception;
    public E save(E entity) throws Exception;
    public E update(Integer id, E entity) throws Exception;
    public boolean delete(Integer id) throws Exception;
}
