package com.studentselection.candidates.services;

import com.studentselection.candidates.dto.*;
import com.studentselection.candidates.entities.AnswerEntity;
import com.studentselection.candidates.entities.CandidateEntity;
import com.studentselection.candidates.entities.CategoryEntity;
import com.studentselection.candidates.entities.UserInformationEntity;
import com.studentselection.candidates.mapper.*;
import com.studentselection.candidates.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class QuestionnaireService {

    @Autowired
    private CandidateCRUDRepository candidateCRUDRepository;
    @Autowired
    private UserInformationRepository userInformationRepository;
    @Autowired
    private AnswerRepository answerRepository;

    @Autowired
    private QuestionsRepository questionsRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private AnswerOutMapper answerOutMapper;
    @Autowired
    private AnswerMapper answerMapper;

    @Autowired
    private QuestionOutMapper questionOutMapper;


    @Transactional
    public List<CategoryEntity> getCategories() throws Exception {
        try{
            List<CategoryEntity> categoryList = categoryRepository.findAll();
            return categoryList;
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }


    @Transactional
    public List<AnswerOutDTO> getAnswers() throws Exception {
        try {
            List<AnswerOutDTO> answerList = answerOutMapper.toDomainList(answerRepository.findAll());

            return answerList;
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }
    public List<AnswerDTO> getDefaultAnswers() throws Exception {
        try {
            List<AnswerDTO> answerList = answerMapper.toDomainList(answerRepository.findAll());

            return answerList;
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @Transactional
    public List<QuestionsOutDTO> getQuestions() throws Exception {
        try {
            List<QuestionsOutDTO> questionList = questionOutMapper.toDomainList(questionsRepository.findAll());
            return questionList;
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }
}
