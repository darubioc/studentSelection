package com.studentselection.filterCandidates.controllers;

import com.studentselection.candidates.services.CandidateCRUDService;
import com.studentselection.candidates.services.QuestionnaireService;
import com.studentselection.filterCandidates.dto.ReportDTO;
import com.studentselection.filterCandidates.enums.ReportType;
import com.studentselection.filterCandidates.services.ReportPersistenceAdapter;
import org.springframework.core.io.Resource;
import com.studentselection.filterCandidates.dto.questionnaire.CriterionQuestionnaire;
import com.studentselection.filterCandidates.services.CandidateSelectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import net.sf.jasperreports.engine.JRException;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "candidatesSelection")
public class CandidateSelectionController {

    @Autowired
    CandidateSelectionService candidateSelectionService;

    @Autowired
    ReportPersistenceAdapter reportPersistenceAdapter;


    @GetMapping("/report")
    public ResponseEntity<Resource> downloadReport(@RequestParam Map<String, Object> params)
            throws JRException, IOException, SQLException {
        ReportDTO dto = reportPersistenceAdapter.getReport(params);

        InputStreamResource streamResource = new InputStreamResource(dto.getStream());
        MediaType mediaType = null;
        if (params.get("reportType").toString().equalsIgnoreCase(ReportType.EXCEL.name())) {
            mediaType = MediaType.APPLICATION_OCTET_STREAM;
        } else {
            mediaType = MediaType.APPLICATION_PDF;
        }

        return ResponseEntity.ok().header("Content-Disposition", "inline; filename=\"" + dto.getFileName() + "\"")
                .contentLength(dto.getLength()).contentType(mediaType).body(streamResource);
    }

    @GetMapping("/{docNum}")
    public ResponseEntity<?> filterCandidates(@PathVariable String docNum){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(candidateSelectionService.filterByDocNum(docNum));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. La consulta no arroja resultados.\""+e+"}");
        }
    }

    @PostMapping("/selectCandidates")
    public ResponseEntity<?> selectCandidates(@RequestBody CriterionQuestionnaire criteriaList){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(candidateSelectionService.selectCandidates(criteriaList));

        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. La consulta no arroja resultados.\""+e+"}");
        }
    }
    @GetMapping("report/{id}")
    public ResponseEntity<?> getReports(@PathVariable Integer id){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(candidateSelectionService.getReportEntities(id));

        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. La consulta no arroja resultados.\""+e+"}");
        }
    }

    @GetMapping("feature/{id}")
    public ResponseEntity<?> getParams(@PathVariable Integer id){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(candidateSelectionService.getReportParams(id));

        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. La consulta no arroja resultados.\""+e+"}");
        }
    }

    @GetMapping("convocation")
    public ResponseEntity<?> getConvocations(){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(candidateSelectionService.getConvocations());

        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. La consulta no arroja resultados.\""+e+"}");
        }
    }

}
