package com.studentselection.filterCandidates.dto;

import com.studentselection.candidates.dto.QuestionDTO;
import lombok.*;

import java.io.Serializable;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class RatedAnswerDTO implements Serializable {

    private Integer id;
    private String name;
    private String description;
    private Double score;
    private QuestionDTO question;

}
