package com.studentselection.filterCandidates.dto;

import com.studentselection.candidates.dto.DocumentTypeDTO;
import lombok.*;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RatedCandidateDTO {

    private Integer id;
    private String names;
    private String surnames;
    private Date birthday;
    private String docNum;
    private DocumentTypeDTO docType;
    private String email;
    private List<RatedUserInformationDTO> userInformationList;
    private Double totalScore;

}
