package com.studentselection.filterCandidates.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class RatedUserInformationDTO implements Serializable {

    private Integer id;
    private RatedAnswerDTO answer;
    private Integer answerId;
    @JsonIgnore
    private RatedCandidateDTO candidate;
    private Integer candidateId;

}
