package com.studentselection.filterCandidates.dto.questionnaire;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class AnswerQuestionnaire {
    public int answerId;
    public int priority;
}
