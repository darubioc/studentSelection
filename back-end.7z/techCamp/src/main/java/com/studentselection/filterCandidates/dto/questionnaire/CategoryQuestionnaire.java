package com.studentselection.filterCandidates.dto.questionnaire;

import lombok.*;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class CategoryQuestionnaire {
    public int categoryId;
    public int weigth;
    public List<AnswerQuestionnaire> answers;
}
