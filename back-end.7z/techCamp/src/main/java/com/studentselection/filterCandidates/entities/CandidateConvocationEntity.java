package com.studentselection.filterCandidates.entities;

import com.studentselection.candidates.entities.CandidateEntity;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="CANDIDATE_CONVOCATION")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class CandidateConvocationEntity implements Serializable {

    @Id
    @Column(name="ID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name="CANDIDATE_ID", insertable = false, updatable = false)
    private CandidateEntity candidate;

    @Column(name="CANDIDATE_ID")
    private Integer candidateId;

    @ManyToOne
    @JoinColumn(name="CONVOCATION_ID", insertable = false, updatable = false)
    private ConvocationEntity convocation;

    @Column(name="CONVOCATION_ID")
    private Integer convocationId;


}
