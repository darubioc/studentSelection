package com.studentselection.filterCandidates.entities;

import com.studentselection.candidates.entities.AnswerEntity;
import com.studentselection.candidates.entities.CandidateEntity;
import com.studentselection.candidates.entities.UserInformationEntity;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity
@Table(name="CONVOCATION")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class ConvocationEntity implements Serializable {

    @Id
    @Column(name="ID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @Column(name="NAME")
    private String name;

    @Column(name="DATECONVOCATION")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateConvocation;



}
