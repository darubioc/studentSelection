package com.studentselection.filterCandidates.entities;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="REPORT")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class DetailReportEntity implements Serializable {

    @Id
    @Column(name="ID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @Column(name="FEATURE")
    private String feature;

    @Column(name="ANSWER")
    private String answer;

    @Column(name="SCORE")
    private Double score;

    @ManyToOne
    @JoinColumn(name="REPORTFK")
    private ReportEntity report;

}
