package com.studentselection.filterCandidates.entities;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity
@Table(name="FEATURE")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class FeatureEntity implements Serializable {

    @Id
    @Column(name="ID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @Column(name="NAME")
    private String name;

    @ManyToOne
    @JoinColumn(name="CONVOCATION", updatable = false, insertable = false)
    private ConvocationEntity convocation;

    @Column(name="CONVOCATION")
    private Integer convocationId;

    @Column(name="WEIGHT")
    private Integer weight;

    @OneToMany(mappedBy = "feature", fetch = FetchType.EAGER)
    private List<PriorityEntity> priorities;
}
