package com.studentselection.filterCandidates.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="PRIORITY")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class PriorityEntity implements Serializable {

    @Id
    @Column(name="ID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @Column(name="NAME")
    private String name;

    @Column(name="VALUE")
    private Integer value;

    @ManyToOne
    @JoinColumn(name="FEATURE",insertable = false,updatable = false)
    @JsonIgnore
    private FeatureEntity feature;

    @Column(name="FEATURE")
    private Integer featureId;

}
