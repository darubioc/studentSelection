package com.studentselection.filterCandidates.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name="REPORTDETAIL")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class ReportDetailEntity implements Serializable {

    @Id
    @Column(name="ID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @Column(name="FEATURE")
    private String feature;

    @Column(name="ANSWER")
    private String answer;

    @Column(name="SCORE")
    private Double score;

    @ManyToOne
    @JoinColumn(name="REPORTFK")
    @JsonIgnore
    private ReportEntity report;
}
