package com.studentselection.filterCandidates.entities;

import com.studentselection.candidates.entities.UserInformationEntity;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity
@Table(name="REPORT")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class ReportEntity implements Serializable {

    @Id
    @Column(name="ID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @Column(name="CANDIDATENAME")
    private String candidateName;

    @Column(name="CANDIDATEID")
    private Integer candidateId;

    @Column(name="TOTALSCORE")
    private Double totalScore;

    @ManyToOne
    @JoinColumn(name="CONVOCATION", updatable = false, insertable = false)
    private ConvocationEntity convocation;

    @OneToMany(mappedBy = "report", fetch = FetchType.EAGER)
    private List<ReportDetailEntity> reportDetail;

    @Column(name="CONVOCATION")
    private Integer convocationId;
}
