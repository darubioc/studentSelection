package com.studentselection.filterCandidates.enums;

public enum ReportType {
    PDF,
    EXCEL
}
