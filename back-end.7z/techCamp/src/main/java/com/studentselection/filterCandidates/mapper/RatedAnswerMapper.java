package com.studentselection.filterCandidates.mapper;

import com.studentselection.candidates.dto.AnswerDTO;
import com.studentselection.candidates.entities.AnswerEntity;
import com.studentselection.candidates.mapper.Mapper;
import com.studentselection.candidates.mapper.QuestionMapper;
import com.studentselection.filterCandidates.dto.RatedAnswerDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RatedAnswerMapper extends Mapper<AnswerEntity, RatedAnswerDTO> {

    @Autowired
    QuestionMapper questionMapper;

    public RatedAnswerDTO toDomain(AnswerEntity answer) {
        return (answer != null) ? RatedAnswerDTO.builder()
                .id(answer.getId())
                .name(answer.getName())
                .description(answer.getDescription())
                .question(questionMapper.toDomain(answer.getQuestion()))
                .build() : null;
    }
    public AnswerEntity toEntity(RatedAnswerDTO answer) {
        return (answer != null) ? AnswerEntity.builder()
                .id(answer.getId())
                .name(answer.getName())
                .description(answer.getDescription())
                .question(questionMapper.toEntity(answer.getQuestion()))
                .build() : null;
    }
}
