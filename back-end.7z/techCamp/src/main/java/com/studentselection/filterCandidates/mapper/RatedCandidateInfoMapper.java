package com.studentselection.filterCandidates.mapper;

import com.studentselection.candidates.dto.CandidateDTO;
import com.studentselection.candidates.entities.CandidateEntity;
import com.studentselection.candidates.mapper.DocumentTypeMapper;
import com.studentselection.candidates.mapper.Mapper;
import com.studentselection.filterCandidates.dto.RatedCandidateDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RatedCandidateInfoMapper extends Mapper<CandidateEntity, RatedCandidateDTO> {

    @Autowired
    DocumentTypeMapper documentTypeMapper;
    @Autowired
    RatedUserInformationMapper ratedUserInformationMapper;


    public RatedCandidateDTO toDomain(CandidateEntity candidate) {
        return RatedCandidateDTO.builder()
                .id(candidate.getId())
                .names(candidate.getNames())
                .surnames(candidate.getSurnames())
                .birthday(candidate.getBirthday())
                .docNum(candidate.getDocNum())
                .docType(documentTypeMapper.toDomain(candidate.getDocType()))
                .email(candidate.getEmail())
                .userInformationList(ratedUserInformationMapper.toDomainList(candidate.getUserInformationList()))
                .build();
    }
    public CandidateEntity toEntity(RatedCandidateDTO candidate) {
         CandidateEntity candidateEntity = CandidateEntity.builder()
                .id(candidate.getId())
                .names(candidate.getNames())
                .surnames(candidate.getSurnames())
                .birthday(candidate.getBirthday())
                .docNum(candidate.getDocNum())
                .docType(documentTypeMapper.toEntity(candidate.getDocType()))
                 .userInformationList(candidate.getUserInformationList()==null?null:ratedUserInformationMapper.toEntityList(candidate.getUserInformationList()))
                 .email(candidate.getEmail())
                 .build();
         return candidateEntity;
    }

}
