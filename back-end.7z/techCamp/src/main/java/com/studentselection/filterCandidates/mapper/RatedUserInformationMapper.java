package com.studentselection.filterCandidates.mapper;

import com.studentselection.candidates.dto.UserInformationDTO;
import com.studentselection.candidates.entities.AnswerEntity;
import com.studentselection.candidates.entities.CandidateEntity;
import com.studentselection.candidates.entities.UserInformationEntity;
import com.studentselection.candidates.mapper.CandidateInfoMapper;
import com.studentselection.candidates.mapper.Mapper;
import com.studentselection.filterCandidates.dto.RatedCandidateDTO;
import com.studentselection.filterCandidates.dto.RatedUserInformationDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RatedUserInformationMapper extends Mapper<UserInformationEntity, RatedUserInformationDTO> {

    @Autowired
    RatedAnswerMapper ratedAnswerMapper;

    public RatedUserInformationDTO toDomain(UserInformationEntity userInfo) {
        return (userInfo != null) ? RatedUserInformationDTO.builder()
                .id(userInfo.getId())
                .answer(ratedAnswerMapper.toDomain(userInfo.getAnswer()))
                .candidateId(userInfo.getCandidate().getId())
                .build() : null;
    }
    public UserInformationEntity toEntity(RatedUserInformationDTO userInfo) {
        return (userInfo != null) ? UserInformationEntity.builder()
                .id(userInfo.getId())
                .answer(ratedAnswerMapper.toEntity(userInfo.getAnswer()))
                .candidate(CandidateEntity.builder().id(userInfo.getCandidateId()).build())
                .build() : null;
    }
    public UserInformationEntity toEntity(RatedUserInformationDTO userInfo, CandidateEntity candidate, AnswerEntity answer) {
        return (userInfo != null) ? UserInformationEntity.builder()
                .id(userInfo.getId() != null ? userInfo.getId() : null)
                .answer(answer)
                .candidate(candidate)
                .build() : null;
    }
}
