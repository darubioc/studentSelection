package com.studentselection.filterCandidates.repositories;

import com.studentselection.filterCandidates.entities.CandidateConvocationEntity;
import com.studentselection.filterCandidates.entities.ConvocationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CandidateConvocationRepository extends JpaRepository<CandidateConvocationEntity,Integer> {
}
