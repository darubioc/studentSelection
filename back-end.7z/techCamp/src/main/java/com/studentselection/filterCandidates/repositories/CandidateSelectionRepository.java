package com.studentselection.filterCandidates.repositories;

import com.studentselection.candidates.entities.CandidateEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CandidateSelectionRepository extends JpaRepository<CandidateEntity,Integer> {

    @Query("SELECT c FROM CandidateEntity c WHERE (lower(c.docNum) LIKE lower(concat('%', ?1, '%')))")
    List<CandidateEntity> filterByDocNum(String docNum);


}
