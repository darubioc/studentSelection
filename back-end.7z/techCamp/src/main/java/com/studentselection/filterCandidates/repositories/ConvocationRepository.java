package com.studentselection.filterCandidates.repositories;

import com.studentselection.candidates.entities.CandidateEntity;
import com.studentselection.filterCandidates.entities.ConvocationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConvocationRepository extends JpaRepository<ConvocationEntity,Integer> {


}
