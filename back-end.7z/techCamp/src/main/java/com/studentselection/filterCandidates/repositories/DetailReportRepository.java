package com.studentselection.filterCandidates.repositories;

import com.studentselection.filterCandidates.entities.DetailReportEntity;
import com.studentselection.filterCandidates.entities.ReportEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DetailReportRepository extends JpaRepository<DetailReportEntity,Integer> {

}
