package com.studentselection.filterCandidates.repositories;

import com.studentselection.filterCandidates.entities.ConvocationEntity;
import com.studentselection.filterCandidates.entities.FeatureEntity;
import com.studentselection.filterCandidates.entities.ReportEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FeatureRepository extends JpaRepository<FeatureEntity,Integer> {

    public List<FeatureEntity> findAllByConvocationId(Integer convocationId);

}
