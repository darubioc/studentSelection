package com.studentselection.filterCandidates.repositories;

import com.studentselection.filterCandidates.entities.FeatureEntity;
import com.studentselection.filterCandidates.entities.PriorityEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PriorityRepository extends JpaRepository<PriorityEntity,Integer> {

}
