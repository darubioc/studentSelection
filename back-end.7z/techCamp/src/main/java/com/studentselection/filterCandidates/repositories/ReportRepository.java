package com.studentselection.filterCandidates.repositories;

import com.studentselection.filterCandidates.entities.PriorityEntity;
import com.studentselection.filterCandidates.entities.ReportEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReportRepository extends JpaRepository<ReportEntity,Integer> {

    public List<ReportEntity> findAllByConvocationId(Integer convocationId);
}
