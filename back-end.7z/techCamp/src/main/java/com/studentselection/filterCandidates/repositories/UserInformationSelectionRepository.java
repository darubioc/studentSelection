package com.studentselection.filterCandidates.repositories;

import com.studentselection.candidates.entities.CandidateEntity;
import com.studentselection.candidates.entities.UserInformationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserInformationSelectionRepository extends JpaRepository<UserInformationEntity,Integer> {

}
