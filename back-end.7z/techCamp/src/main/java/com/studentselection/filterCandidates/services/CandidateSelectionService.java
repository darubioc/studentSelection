package com.studentselection.filterCandidates.services;

import com.studentselection.candidates.entities.AnswerEntity;
import com.studentselection.candidates.entities.CandidateEntity;
import com.studentselection.candidates.repositories.AnswerRepository;
import com.studentselection.candidates.repositories.CategoryRepository;
import com.studentselection.filterCandidates.dto.RatedCandidateDTO;
import com.studentselection.filterCandidates.dto.RatedUserInformationDTO;
import com.studentselection.filterCandidates.dto.questionnaire.AnswerQuestionnaire;
import com.studentselection.filterCandidates.dto.questionnaire.CategoryQuestionnaire;
import com.studentselection.filterCandidates.dto.questionnaire.CriterionQuestionnaire;
import com.studentselection.filterCandidates.entities.*;
import com.studentselection.filterCandidates.mapper.RatedCandidateInfoMapper;
import com.studentselection.filterCandidates.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class CandidateSelectionService{

    @Autowired
    private CandidateSelectionRepository candidateSelectionRepository;

    @Autowired
    private ConvocationRepository convocationRepository;

    @Autowired
    private CandidateConvocationRepository candidateConvocationRepository;

    @Autowired
    private PriorityRepository priorityRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private AnswerRepository answerRepository;
    @Autowired
    private ReportRepository reportRepository;

    @Autowired
    private ReportDetailRepository reportDetailRepository;

    @Autowired
    private FeatureRepository featureRepository;

    @Autowired
    private RatedCandidateInfoMapper ratedCandidateInfoMapper;

    @Transactional
    public List<?> filterByDocNum(String docNum) throws NoSuchElementException {
        try{
            return candidateSelectionRepository.filterByDocNum(docNum);
        }catch (Exception e) {
            throw new NoSuchElementException();
        }
    }

    /**
     * Método encargado de orquestar la selección de candidatos y el guardado del reporte:
     * - Obtención de la lista de candidatos
     * - Calificación de candidatos con base en los criterios parametrizados
     * - Guardado del resultado de la convocatoria / seleccón de candidatos.
     * @param criteriaList corresponde al grupo de criterios otorgados por el usuario para calificar los candidatos.
     * @return ConvocationEntity datos de la convocatoria (general) creada para posibilitar la consulta de la misma.
     * @throws Exception para errores y operaciones frustradas
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    @Transactional
    public ConvocationEntity selectCandidates(CriterionQuestionnaire criteriaList) throws NoSuchElementException {
        try{
            List<CandidateEntity> candidateList = candidateSelectionRepository.findAll();
            List<RatedCandidateDTO> ratedCandidates = qualifyCandidates(
                    ratedCandidateInfoMapper.toDomainList(candidateList),criteriaList);
            ConvocationEntity convEntity = saveConvocationResults(ratedCandidates,criteriaList);
            return convEntity;
        }catch (Exception e) {
            throw new NoSuchElementException();
        }
    }

    /**
     * Método encargado de calificar la lista de candidatos con respecto a los criterios otorgados:
     * - Recorrido de candidatos
     * - Recorrido del detalle de las respuestas de los candidatos
     * - Recorrido de los criterios
     * - Recorrido de las prioridades dentro de cada criterio
     * - Comparación para encontrar coincidencias entre el detalle de información y los criterios otorgados.
     *      ->Asignación de puntuación según se encuentre o no coincidencias con los criterios.
     * @param ratedCandidateList corresponde al listado de candidatos a evaluar.
     * @param criteriaList corresponde al grupo de criterios otorgados por el usuario para calificar los candidatos.
     * @return List<RatedCandidateDTO> Listado de candidatos evaluados.
     * @throws Exception para errores y operaciones frustradas
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    public List<RatedCandidateDTO> qualifyCandidates(List<RatedCandidateDTO> ratedCandidateList,
                                                     CriterionQuestionnaire criteriaList) throws NoSuchElementException {
        try {
            for (RatedCandidateDTO candidateRated:ratedCandidateList) {
                if(candidateRated.getUserInformationList().size()>0){
                    for (RatedUserInformationDTO userInfo:candidateRated.getUserInformationList()) {
                        criteriaList.getCategories().forEach(criteria -> {
                                    criteria.answers.forEach(answer ->{
                                        if(userInfo.getAnswer().getId() == answer.getAnswerId()){
                                            userInfo.getAnswer().setScore(((double)criteria.getWeigth()*(1 / ((double)answer.getPriority()))));
                                            candidateRated.setTotalScore(candidateRated.getTotalScore()!=null?
                                                    (double)candidateRated.getTotalScore()+(double)userInfo.getAnswer().getScore()
                                                    : (double)userInfo.getAnswer().getScore());
                                        }
                                        else if(userInfo.getAnswer().getScore()==null)
                                            userInfo.getAnswer().setScore((double) 0);
                                        if(candidateRated.getTotalScore()==null)
                                            candidateRated.setTotalScore((double) 0);
                                        userInfo.setCandidateId(candidateRated.getId());
                                    });
                                }
                        );
                    }
                    if(candidateRated.getTotalScore()==null){
                        System.out.println("entro");
                    }
                }else{
                    candidateRated.setTotalScore((double) 0);
                }
            }
            return ratedCandidateList;
        } catch (Exception e) {
            throw new NoSuchElementException();
        }
    }

    /**
     * Método encargado de guardar el reporte correspondiente a la selección de candidatos:
     * - Creación de convocatoria
     * - Recorrido de candidatos evaluados y guardado de un reporte por cada candidato con su puntuación total lograda.
     * - Cuando el candidato tenga un listado de información detalle, se ejecutará un ciclo que guardará este detalle
     *   en la tabla REPORT_DETAIL
     * - Recorrido de los criterios y prioridades, guardando la trazabilidad de los criterios y prioridades usadas para
     *   esta convocatoria;
     * @param candidateRateList corresponde al listado de candidatos a evaluar.
     * @param criteriaList corresponde al grupo de criterios otorgados por el usuario para calificar los candidatos.
     * @return ConvocationEntity corresponde a la convocatoria creada, para su posterior consulta.
     * @throws Exception para errores y operaciones frustradas
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    @Transactional
    public ConvocationEntity saveConvocationResults(List<RatedCandidateDTO> candidateRateList,
                                                    CriterionQuestionnaire criteriaList) throws Exception{
        try{
            ConvocationEntity convEnt = convocationRepository.save(ConvocationEntity.builder()
                    .name(criteriaList.getNameConvocation())
                    .dateConvocation(new Date())
                    .build());
            for (RatedCandidateDTO ratedCandidate: candidateRateList) {
                candidateConvocationRepository.save(
                        CandidateConvocationEntity.builder()
                                .candidateId(ratedCandidate.getId())
                                .convocationId(convEnt.getId())
                                .build()
                );
                ReportEntity reportEntity = reportRepository.save(
                        ReportEntity.builder()
                                .candidateName(ratedCandidate.getNames() + " " + ratedCandidate.getSurnames()
                                + " docNum: " + ratedCandidate.getDocNum())
                                .candidateId(ratedCandidate.getId())
                                .totalScore(ratedCandidate.getTotalScore()==null?0:ratedCandidate.getTotalScore())
                                .convocationId(convEnt.getId())
                                .build()
                );
                if(ratedCandidate.getUserInformationList().size()>0){
                    for (RatedUserInformationDTO userInfo : ratedCandidate.getUserInformationList()) {
                        reportDetailRepository.save(ReportDetailEntity.builder()
                                .feature(userInfo.getAnswer().getQuestion().getCategory().getName())
                                .answer(userInfo.getAnswer().getName())
                                .score(userInfo.getAnswer().getScore())
                                .report(reportEntity)
                                .build()
                        );
                    }
                }

            }
            for (CategoryQuestionnaire category : criteriaList.getCategories()) {
                FeatureEntity featureEnt = FeatureEntity.builder()
                        .name(String.valueOf(categoryRepository.findById(category.getCategoryId()).get().getName()))
                        .convocation(convEnt)
                        .convocationId(convEnt.getId())
                        .weight(category.getWeigth())
                        .build();
                featureRepository.save(featureEnt);
                for (AnswerQuestionnaire ansQuest:category.getAnswers()) {
                    priorityRepository.save(
                            PriorityEntity.builder()
                                    .name(String.valueOf(answerRepository.findById(ansQuest.getAnswerId()).get().getName()))
                                    .feature(featureEnt)
                                    .featureId(featureEnt.getId())
                                    .value(ansQuest.getPriority())
                                    .build()
                    );
                }
            }
            return convEnt;
        }catch (Exception e){
            throw new Exception("Error al guardar los datos. "+e.getMessage());
        }
    }

    /**
     * Método encargado de listar los reportes
     * @param convocationEntityId corresponde al identificador de la convocatoria que queremos consultar.
     * @return List<ReportEntity> otorga el listado de reportes para determinada convocatoria.
     * @throws Exception para errores y operaciones frustradas
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    public List<ReportEntity> getReportEntities(Integer convocationEntityId) throws Exception {
        try{
            return reportRepository.findAllByConvocationId(convocationEntityId);
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }

    }

    /**
     * Método encargado de listar los criterios usados en una convocatoria
     * @param convocationEntityId corresponde al identificador de la convocatoria que queremos consultar.
     * @return List<FeatureEntity> otorga el listado de criterios usados en determinada convocatoria.
     * @throws Exception para errores y operaciones frustradas
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    public List<FeatureEntity> getReportParams(Integer convocationEntityId) throws Exception {
        try{
            return featureRepository.findAllByConvocationId(convocationEntityId);
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }

    /**
     * Método encargado de listar las convocatorias ejecutadas
     * @return List<ConvocationEntity> otorga el listado de convocatorias realizadas.
     * @throws Exception para errores y operaciones frustradas
     * @author DiegoAndresRubioCasallas - CC1032493492
     */
    public List<ConvocationEntity> getConvocations() throws Exception {
        try{
            return convocationRepository.findAll();
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }

    }
}
