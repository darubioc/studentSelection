package com.studentselection.filterCandidates.services;

import com.studentselection.filterCandidates.commons.JasperReportManager;
import com.studentselection.filterCandidates.dto.ReportDTO;
import com.studentselection.filterCandidates.enums.ReportType;
import net.sf.jasperreports.engine.JRException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

@Service
public class ReportPersistenceAdapter {

    @Autowired
    private JasperReportManager reportManager;

    @Autowired
    private DataSource dataSource;

    public ReportDTO getReport(Map<String, Object> params) throws JRException, IOException, SQLException {
        String fileName = "resultadosConvocatoria";
        ReportDTO ReportDTO = new ReportDTO();
        String extension = params.get("reportType").toString().equalsIgnoreCase(ReportType.EXCEL.name()) ? ".xlsx"
                : ".pdf";
        ReportDTO.setFileName(fileName + extension);

        ByteArrayOutputStream stream = reportManager.export(fileName, params.get("reportType").toString(), params,
                dataSource.getConnection());

        byte[] bs = stream.toByteArray();
        ReportDTO.setStream(new ByteArrayInputStream(bs));
        ReportDTO.setLength(bs.length);

        return ReportDTO;
    }
}
